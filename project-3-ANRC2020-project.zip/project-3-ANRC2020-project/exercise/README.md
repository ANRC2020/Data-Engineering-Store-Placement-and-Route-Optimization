# Recommended, but Optional, Exercise

Solutions are provided in the solutions directory.
