### University of California, Berkeley
### Master of Information and Data Science Program (MIDS)
### w205 - Fundamentals of Data Engineering

* Year: 2024
* Semester: Spring
* Section: 008
* Instructor: Shiraz Schakraverty
* Team Members:
    * Achyuth Kolluru
    * Abbas Siddiqui
